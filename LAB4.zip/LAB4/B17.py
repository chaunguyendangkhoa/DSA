def find_kth_smallest(a, k):
    n = len(a)

    for i in range(k):
        min_idx = i
        for j in range(i + 1, n):
            if a[j] < a[min_idx]:
                min_idx = j
                
        a[i], a[min_idx] = a[min_idx], a[i]
        

    return a[k - 1]


a = [7, 2, 5, 1, 9]
k = 3
result = find_kth_smallest(a, k)
print("Phần tử nhỏ thứ k là:", result)