
a = [(2, 'a'), (2, 'b'), (1, 'c')]
n = len(a)

for i in range(n - 1):
    min_idx = i
    for j in range(i + 1, n):
        if a[j][0] < a[min_idx][0]:
            min_idx = j
            
   
    key = a[min_idx]
 
    while min_idx > i:
        a[min_idx] = a[min_idx - 1]
        min_idx -= 1
        
  
    a[i] = key

print("Mảng sau khi sắp xếp ổn định:", a)